function Home({ details }) {
  return (
    <div>
      Hello World!
    </div>
   
  );
}

export default Home;


